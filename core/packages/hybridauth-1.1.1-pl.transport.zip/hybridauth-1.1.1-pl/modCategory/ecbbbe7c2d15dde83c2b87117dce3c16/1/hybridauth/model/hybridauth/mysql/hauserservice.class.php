<?php
require_once (dirname(dirname(__FILE__)) . '/hauserservice.class.php');
class haUserService_mysql extends haUserService {}