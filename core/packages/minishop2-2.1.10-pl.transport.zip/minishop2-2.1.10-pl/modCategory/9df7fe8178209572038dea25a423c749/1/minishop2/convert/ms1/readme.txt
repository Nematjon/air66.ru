This console scripts to convert the goods of miniShop to miniShop2.
Use it only at your own risk!


- ms2product
Converts all categories and products. It can fill vendors with values from add2 (or other) field.

- ms2gallery
Imports images of products. By default, it truncate table msProductFile on each run.